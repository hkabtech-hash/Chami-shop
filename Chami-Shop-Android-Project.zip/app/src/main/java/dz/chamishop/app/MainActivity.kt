package dz.chamishop.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val purple = Color.rgb(137, 65, 230)
    private val dark = Color.rgb(17, 17, 22)
    private val card = Color.rgb(31, 29, 38)
    private var cartCount = 0
    private lateinit var cartButton: Button
    private lateinit var content: LinearLayout

    data class Product(val name: String, val category: String, val price: String, val icon: String)

    private val products = listOf(
        Product("Smartphone Galaxy", "هواتف ذكية", "من 45,000 دج", "📱"),
        Product("iPhone", "هواتف ذكية", "من 95,000 دج", "📱"),
        Product("سماعات Bluetooth", "سماعات", "3,500 دج", "🎧"),
        Product("شاحن سريع USB-C", "شواحن وكابلات", "2,000 دج", "🔌"),
        Product("ساعة ذكية", "ساعات ذكية", "6,500 دج", "⌚"),
        Product("حافظة هاتف", "حافظات", "800 دج", "📦")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        window.decorView.systemUiVisibility = 0
        showHome()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun base(): LinearLayout {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            layoutParams = LinearLayout.LayoutParams(-1, -1)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
        }
        val brand = TextView(this).apply {
            text = "Chami Shop"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        cartButton = Button(this).apply {
            text = "السلة (0)"
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener { showCart() }
        }
        header.addView(cartButton)
        outer.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(24))
        }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return outer
    }

    private fun showHome() {
        val outer = base()
        content.removeAllViews()

        val banner = TextView(this).apply {
            text = "كل ما تحتاجه لهاتفك\nفي مكان واحد 💜"
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(28), dp(16), dp(28))
            background = rounded(purple, 18)
        }
        content.addView(banner, marginParams(bottom = 18))

        val search = EditText(this).apply {
            hint = "ابحث عن هاتف أو إكسسوار..."
            textSize = 15f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(card, 12)
        }
        content.addView(search, marginParams(bottom = 16))
        search.setOnEditorActionListener { _, _, _ ->
            val q = search.text.toString().trim()
            showProducts(products.filter { it.name.contains(q, true) || it.category.contains(q, true) })
            true
        }

        sectionTitle("الأقسام")
        val categories = listOf("الكل", "هواتف ذكية", "سماعات", "شواحن وكابلات", "حافظات", "ساعات ذكية")
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        categories.forEach { cat ->
            val b = Button(this).apply {
                text = cat
                textSize = 11f
                setTextColor(Color.WHITE)
                setBackgroundTintList(android.content.res.ColorStateList.valueOf(card))
                setOnClickListener {
                    val filtered = if (cat == "الكل") products else products.filter { it.category == cat }
                    showProducts(filtered)
                }
            }
            row.addView(b, LinearLayout.LayoutParams(-2, dp(46)).apply { rightMargin = dp(6) })
        }
        val horizontal = HorizontalScrollView(this)
        horizontal.addView(row)
        content.addView(horizontal, marginParams(bottom = 14))

        sectionTitle("منتجات مقترحة")
        products.take(4).forEach { addProductCard(it) }
        setContentView(outer)
    }

    private fun showProducts(items: List<Product>) {
        val outer = base()
        content.removeAllViews()
        sectionTitle("المنتجات")
        if (items.isEmpty()) {
            content.addView(label("لا توجد نتائج مطابقة.", 16, Color.WHITE))
        } else items.forEach { addProductCard(it) }
        val back = Button(this).apply {
            text = "العودة للرئيسية"
            setOnClickListener { showHome() }
        }
        content.addView(back, marginParams(top = 12))
        setContentView(outer)
    }

    private fun addProductCard(p: Product) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(card, 14)
        }
        val icon = TextView(this).apply {
            text = p.icon
            textSize = 34f
            gravity = Gravity.CENTER
        }
        box.addView(icon, LinearLayout.LayoutParams(dp(64), dp(68)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(label(p.name, 16, Color.WHITE, true))
        info.addView(label(p.category, 12, Color.LTGRAY))
        info.addView(label(p.price, 14, Color.rgb(202, 164, 255), true))
        box.addView(info, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) })
        val add = Button(this).apply {
            text = "+"
            textSize = 20f
            setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener {
                cartCount++
                cartButton.text = "السلة ($cartCount)"
                Toast.makeText(this@MainActivity, "تمت الإضافة إلى السلة", Toast.LENGTH_SHORT).show()
            }
        }
        box.addView(add)
        content.addView(box, marginParams(bottom = 10))
    }

    private fun showCart() {
        val outer = base()
        content.removeAllViews()
        sectionTitle("سلة المشتريات")
        content.addView(label("عدد المنتجات المضافة: $cartCount", 18, Color.WHITE))
        content.addView(label("هذه نسخة أولية؛ سيتم ربط الطلبات والدفع وقاعدة البيانات في المرحلة التالية.", 14, Color.LTGRAY), marginParams(top = 12))
        val clear = Button(this).apply {
            text = "إفراغ السلة"
            setOnClickListener {
                cartCount = 0
                cartButton.text = "السلة (0)"
                showCart()
            }
        }
        content.addView(clear, marginParams(top = 16))
        val back = Button(this).apply {
            text = "متابعة التسوق"
            setOnClickListener { showHome() }
        }
        content.addView(back, marginParams(top = 8))
        setContentView(outer)
    }

    private fun sectionTitle(s: String) {
        content.addView(label(s, 19, Color.WHITE, true), marginParams(top = 8, bottom = 10))
    }

    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun rounded(color: Int, radius: Int): android.graphics.drawable.GradientDrawable =
        android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun marginParams(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }
}
